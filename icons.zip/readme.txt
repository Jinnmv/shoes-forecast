Icojoy "Free web development weather icons (34aL) volume 6.0" icons set

Ammount of icons:
16

Colors: 
1. Colored with shadow
2. Colored without shadow 
3. Grey
4. 30% transparent

Icon Sizes:
24x24

File Types:
.ico (RGBA, 256 color, 16 color), 
.tiff (RGBA)
.gif (indexed)
.bmp (RGB - 1 color background), 
.png (RGBA)

Note: These icons are free to use in any kind of commercial or non-commercial project unlimited times.